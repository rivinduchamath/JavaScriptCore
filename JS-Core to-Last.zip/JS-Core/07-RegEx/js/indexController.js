










$("#btnSaveCustomer").attr("disabled",true);

$("#txtCustomerID").on("keyup",function (e) {
    var insertVal=$("#txtCustomerID").val();
    var regEx=/^(C00)[-]{1}[0-9]{3,5}$/;

    if (regEx.test(insertVal)){
        $("#txtCustomerID").css("border","2px solid green");
        if (e.code=="Enter"){
            $("#txtCustomerName").focus();
        }
    } else{
        $("#txtCustomerID").css("border","2px solid red");
    }
});

























// $("#btnSaveCustomer").click(function () {
//     $("tbody tr").off("click");
//     $("tbody tr").off("dblclick");
//     var customerID = $("#txtCustomerID").val();
//     var customerName = $("#txtCustomerName").val();
//     var customerAddress = $("#txtCustomerAddress").val();
//     var customerSalary = $("#txtCustomerSalary").val();
//
//
//     var row = "<tr>" +
//         "<td>" + customerID + "</td> " +
//         "<td>" + customerName + "</td>" +
//         " <td>" + customerAddress + "</td> " +
//         "<td>" + customerSalary + "</td>" +
//         "</tr>";
//
//
//     $("#tableBody").append(row);
//
//
//     $("tbody tr").on("click", function () {
//         var customerID = $($(this).children()[0]).text();
//         var customerName = $($(this).children()[1]).text();
//         var customerAddress = $($(this).children()[2]).text();
//         var customerSalary = $($(this).children()[3]).text();
//
//         $("#txtCustomerID").val(customerID);
//         $("#txtCustomerName").val(customerName);
//         $("#txtCustomerAddress").val(customerAddress);
//         $("#txtCustomerSalary").val(customerSalary);
//     });
//
//     $("tbody tr").on("dblclick", function () {
//         $(this).fadeOut(2000);
//     });
//
//     clearAll();
//
// });
//
//
// function clearAll() {
//     $("#txtCustomerID").val("");
//     $("#txtCustomerName").val("");
//     $("#txtCustomerAddress").val("");
//     $("#txtCustomerSalary").val("");
//     $("#txtCustomerID").focus();
// }
//
//
//
