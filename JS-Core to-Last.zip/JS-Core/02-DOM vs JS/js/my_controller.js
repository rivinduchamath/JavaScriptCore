

// var h1List=document.getElementsByTagName("h1");
//
//
// h1List[0].style.color="red";


var m=document.getElementsByTagName("h1")[0];
m.addEventListener("click",function(){
    alert("hello");
});

var m2=document.getElementsByTagName("h1")[1];
m2.addEventListener("dblclick",function(){
    m2.style.color="orange";
});

m2.addEventListener("click",function(){
    m2.style.color="red";
});

var m3=document.getElementsByTagName("h2")[0];
m3.addEventListener('click',function () {
   var p= document.getElementsByTagName("p")[0];
   p.remove();
});