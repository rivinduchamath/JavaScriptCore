// getCustomerName();
/*alert("ss");
console.log("jfnsjnfjesnfijes");

// console.log("Print Me"); single line Comments
console.log("DD");

/!*console.log(19);
console.log(19);multi line comments
console.log(19);
console.log(19);
console.log(19);*!/


var customerName="Dasun";
customerName=100;
customerName=true;
var customerName="Malinga";

console.log(typeof customerName);


if(true){
    var name="Ranuka";


}

console.log(name);*/


// let customerName="Dasun";
// console.log(customerName);
// customerName=100;
// let customerName="Dasun";
// console.log(customerName);

// if(true){
//     let customer="Dasun";
//
// }
// console.log(customer);


//
// const customerName="Ranjith Suranga";
// console.log(customerName);
// customerName="ancdf";
// console.log(customerName);
// const customerName="Ranjith Suranga";


// var id=100;
//
// {
//
//    let name="dasun";
// }
//
// if(x){
//     var x;
// }


// function getCustomerName() {
//
//     console.log("hello there");
//     console.log("how are you");
//     let abc="IJSE";
//     console.log(abc);
//
//
// }




// we have five datatypes in js
// Strign
//number
// boolean
// null
//undefined

/*// STRING
var string='This is a single Quto String';
var string2="This is a double Quto String";
console.log(typeof string);
console.log(typeof string2);

// BOOLEAN
var bool=true;
var bool2=false;
console.log(typeof bool,typeof bool2);


// NUMBERS
var num1=100;
var num2=10.0;

console.log(typeof num1,typeof num2);

var decimal=10;
var binary=0b1010;
var octal=0o10;
var hexDecimal=0xA;
console.log(typeof binary);*/


// var i;
// console.log(typeof i);
//
// var n=null;
// console.log(typeof n);

/*

var customerID="C001";
var customerName="Danuka";
var customerAddress="Galle";
var customerSalray=10000;
*/


// literal base objects

/*var customerOb={
    "customerID": "C001",
    "customerName":"Danuka",
    "customerAddress":"Galle",
    "customerSalray":"10000"
}*/

/*
console.log(customerOb.customerID);


var i=parseInt("100");
console.log(typeof i);


var myArray=[100,200,300,400,500];
undefined
myArray[0];
100
myArray.push(600);
// 6
myArray;
// (6) [100, 200, 300, 400, 500, 600]
myArray.push(700);
// 7
myArray;
// (7) [100, 200, 300, 400, 500, 600, 700]
myArray.pop();
// 700
myArray.pop();
// 600
myArray.unshift(50);
// 6
myArray;
// (6) [50, 100, 200, 300, 400, 500]
myArray.unshift(10);
// 7
myArray;
// (7) [10, 50, 100, 200, 300, 400, 500]
myArray.shift();
// 10
myArray.shift();
// 50
myArray.shift();
// 100
myArray;
// (4) [200, 300, 400, 500]
myArray.splice(1,1);
// [300]
// myArray;
// (3) [200, 400, 500]
var d=myArray.slice();
undefined
d.shift();




// loops and iteration

// for loop
for(var i=0;i<10;i++){
    console.log(i);

}
*/


// var m=0;
// while(m<10){
//     console.log(m);
//     m++;
// }



// var s=0;
// do{
//     console.log(s);
//     s++;
// }while(s<10);




// controll statement

// var test=30;
//
// if (test==10){
//     console.log("Test is 10");
// } else if(test==20){
//     console.log("Test is 20");
// }else{
//     console.log("Test is nothing");
// }

//
// var mylocation="Galle";
// undefined
// switch(mylocation){
//     case "Galle":
//         console.log("You are selected Galle");
//         break;
//     case "Panadura":
//         console.log("You are selected Panadura");
//         break;
//     default:
//         console.log("You are not selected");
// }



// string literals
/*var string="Hello IJSE how are you..?";
undefined
string.length
25
string.indexOf("z");
-1
string.charAt(0);
"H"
string.charCodeAt(1);
101
string.substr(3,7);
"lo IJSE"
string.toLocaleUpperCase();
"HELLO IJSE HOW ARE YOU..?"
string.toLowerCase();
"hello ijse how are you..?"
string.toUpperCase();
"HELLO IJSE HOW ARE YOU..?"
var s2="   Hello IJSE   ";
undefined
s2.trim();
"Hello IJSE"
s2.trimLeft();
"Hello IJSE   "
s2.trimRight();
"   Hello IJSE"*/


// constructor base objects

function Customer(id,name,address,salary){
    var _id=id;
    var _name=name;
    var _address=address;
    var _salary=salary;

    this.getCustomerID=function(){
        return _id;
    }
    this.getCustomerName=function(){
        return _name;
    }
    this.getCustomerAddress=function(){
        return _address;
    }
    this.getCustomerSalary=function(){
        return _salary;
    }
    this.setCustomerID=function(id){
        _id=id;
    }
    this.setCustomerName=function(name){
        _name=name;
    }
    this.setCustomerAddress=function (address) {
        _address=address;
    }
    this.setCustomerSalary=function (salary) {
        _salary=salary;
    }

}


var c={
    "id":"M001",
    "name":"Dasun"
}

Object.getOwnPropertyDescriptor(c,"id");

Object.keys(c);
// (2) ["id", "name"]0: "id"1: "name"length: 2__proto__: Array(0)
Object.defineProperty(c,"id",{
    writable:true,
    enumerable:false,
    configurable:true
});
// {name: "Dasun", id: "M001"}
Object.getOwnPropertyDescriptor(c,"id");
// {value: "M001", writable: true, enumerable: false, configurable: true}configurable: trueenumerable: falsevalue: "M001"writable: true__proto__: Object
Object.keys(c);
// ["name"]
Object.defineProperty(c,"id",{
    writable:true,
    enumerable:true,
    configurable:true
});


// accsessor properties
//these dont have directly assinged values
Object.defineProperty(c,"address",{
    get(){
        return address;
    },
    set(add){
        address=add;
    },
    enumarable:true,
    configurable:true
});


// {id: "M001", name: "Dasun"}
Object.keys(c);
// (2) ["id", "name"]
Object.defineProperty(c,"id",{
    writable:true,
    enumerable:true,
    configurable:false
});
// {id: "M001", name: "Dasun"}
delete c.id
// false
// Object.defineProperty(c,"id",{
//     writable:false,
//     enumerable:true,
//     configurable:true
// }); this is error becase we cannot update any configuration after we false cofiguration descriptor




